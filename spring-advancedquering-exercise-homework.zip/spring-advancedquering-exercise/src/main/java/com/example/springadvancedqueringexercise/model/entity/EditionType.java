package com.example.springadvancedqueringexercise.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
