package com.example.springadvancedqueringexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAdvancedqueringExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAdvancedqueringExerciseApplication.class, args);
    }

}
