package com.example.springadvancedqueringexercise.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
