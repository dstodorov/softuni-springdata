package com.example.springadvancedqueringexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAdvancedqueringExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
